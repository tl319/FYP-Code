function dtxt = DDPiODE1006(t,x,ft,f)
dtxt = zeros(20, 1); 
f = interp1(ft,f,t);

global S
global L

global A_fom

   
Dummy = zeros(1006,1006); 
Dummy(5,6) = -1;
Dummy(6,5) = 1;
global B_fom
global C_fom

COPY_S = S;
temp = reshape(COPY_S,1,[]);
BL = B_fom*L;
Flat_BL = reshape(BL,1,[]);
Matrix_x = reshape(x,[1006,16]);

t
dtxt = ([(kron(eye(16),(A_fom+Dummy.*f))- kron(S',eye(1006)))] *x + Flat_BL');

% dtxt = ( ...
%     (reshape((A_fom+(Dummy.*f)) * reshape(x,[1006,16]),1,[]))' ...
%     - (reshape((reshape(x,[1006,16])*S),1,[]))' ...
%     + (Flat_BL)' ...
%     ) /10;

end
