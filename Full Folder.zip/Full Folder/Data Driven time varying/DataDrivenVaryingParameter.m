%clear 
close all

load("fom.mat","A","B","C");

global A_fom
A_fom = full(A);


global B_fom
%B_fom = ones(1006,1);
B_fom=B;
global C_fom;
%C_fom = ones(1,1006);
C_fom=C;

ft = linspace(0,10,11);


%f= (10+10*exp(-0.1*ft));
f = 10*ft;
sys = ss(A_fom,B_fom,C_fom,0);
bode(sys);

figure
plot(f)


global A_vary
for idx = 1:length(f)
    A_vary(:,:,idx) = A_fom;
    A_vary(5,6) = 400-f(idx);
    A_vary(6,5) = -400+f(idx);
end    

%Select S, ensuring no shared eigen values with A
global S

S = zeros(16,16);
S(1,1) = 0; S(1,2) = 1; S(2,1) = -1; S(2,2) = 0;
S(3,3) = 0; S(3,4) = 50; S(4,3) = -50; S(4,4) = 0;
S(5,5) = 0; S(5,6) = 100; S(6,5) = -100; S(6,6) = 0;
S(7,7) = 0; S(7,8) = 200; S(8,7) = -200; S(8,8) = 0;
S(9,9) = 0; S(9,10) = 400; S(10,9) = -400; S(10,10) = 0;
S(11,11) = 0; S(11,12) = 75; S(12,11) = -75; S(12,12) = 0;
S(13,13) = 0; S(13,14) = 500; S(14,13) = -500; S(14,12) = 0;
S(15,15) = 0; S(15,16) = 700; S(16,15) = -700; S(16,12) = 0;

%Select L, ensuring (S,L) Observable
global L
L = zeros(1,16);
L(1,1) = 1; L(1,2) = 0; L(1,3) = 1; L(1,4) = 0;
L(1,5) = 1; L(1,6) = 0; L(1,7) = 1; L(1,8) = 0;
L(1,9) = 1; L(1,10) = 0; L(1,11) = 1; L(1,12) = 0;
L(1,13) = 1; L(1,14) = 0; L(1,15) = 1; L(1,16) = 0;

%Scale L
L = L;

global PI

% PI_Initial = sylvester(A_vary(:,:,1),-S,-B_fom*L);
% tspan = [0, 10];
% testpi = PI_Initial;
% flat_testpi = reshape(testpi,1,[]);
% [t_pi,ResultPi] = ode45(@(t,ResultPi) DDPiODE1006(t,ResultPi,ft,f),tspan,flat_testpi);
% CheckPi = reshape(ResultPi',1006,16,[]);
% 
% 
% 
% %Solve ODE, plug in ft and f for parameter
% x0 = rand(1022,1); 
% tspan = t_pi;
% [t_red,x1] = ode45(@(t,x) DDParamODE1006(t,x,ft,f),tspan,x0);
% xT1 =x1';


%Calculate transient response
y1 = C_fom * xT1(17:1022,:);
yss1=zeros(1,3025);
for idx = 1:length(t_pi)
    yss1(:,idx) = C_fom * CheckPi(:,:,idx) * xT1(1:16,idx);
end

dataw1 = xT1(1:16,:)';
datay1 = y1(:,:)';

clear H_vary
clear CPI

CPI=zeros(16,3025);
for idx = 1:(length(t_pi)-32);
    CPI(:,idx) = dataw1(idx:idx+31,:) \ datay1(idx:idx+31);
    H_vary(:,idx) = C_fom * CheckPi(:,:,idx);    
end

% error1 = CPI - H_vary;


global eig_f
eig_f = [ -1+100*i, -1-100*i, -20+200*i, -20-200*i, -40+400*i, -40-400*i, -1, -100, -250, -350, -450, -550, -650, -750, -910, -1000,];
% %alt_eig_f_real = [ -1+100*i, -1-100*i, -1+200*i, -1-200*i, -1+400*i, -1-400*i, -33, -150, -250, -350, -450, -550, -650, -750, -999, -1000,];
 

global G
G = place(S',L',eig_f);

global F
F = S- G'*L;

x0_red = x0(1:32);
tspan = t_pi;
[t,x_red] = ode45(@DDSimpleRedODE,tspan,x0_red);
xT_red = x_red';

for idx = 1:(length(t)-32)
    y_red(:,idx) = H_vary(:,idx)' * xT_red(17:32,idx);
    yss_red(:,idx) = H_vary(:,idx)' * xT_red(1:16,idx);
    y_red_est(:,idx) = CPI(:,idx)' * xT_red(17:32,idx);
    yss_red_est(:,idx) = CPI(:,idx)' * xT_red(1:16,idx);
end



% figure
% plot(t(1:end-16),y1(1:end-16))
% hold on
% plot(t(1:end-16), y_red)
% hold on
% plot(t(1:end-16),y_red_est);
% title('Comparison of the output of the original Model and the Reduced Models')
% legend('Original Model','Reduced Model','Data Driven Reduced Model')
% 
% figure
% plot(t(1:3009),y1(1:3009));
% hold on
% plot(t(1:3009),y_red_est);

for idx = 1:16
figure
plot(t(1:2993),H_vary(idx,1:2993));
hold on
plot(t(1:2993),CPI(idx,1:2993));
title('Comparing Calculated CPi with data-driven CPI')
legend('Correct CPI', 'Data-driven CPI')
end