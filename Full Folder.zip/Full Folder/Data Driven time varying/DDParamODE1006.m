function dtxt = DDParamODE1006(t,x,ft,f)
dtxt = zeros(1022, 1); 
f = interp1(ft,f,t);

global S
global L


global A_fom

   
Dummy = zeros(1006,1006); 
Dummy(5,6) = -1;
Dummy(6,5) = 1;
global B_fom
global C_fom


t
dtxt = [S, zeros(16,1006); B_fom*L, A_fom+(Dummy.*f)] * x;

end
