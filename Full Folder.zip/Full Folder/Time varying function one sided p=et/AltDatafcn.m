function [A,B,C,D,E,dx0,x0,u0,y0,Delays] = AltDatafcn(t)

global alt_F
global alt_G
global H_vary
global fort


A =  alt_F;
B = alt_G';
[~, index] = min(abs(fort-t));
C = H_vary(:,index+1)';
% C = H_vary(:,round(100*t)+1)';
D = 0;
E = [];
dx0 = [];
x0 = [];
u0 = [];
y0 = [];
Delays = [];

