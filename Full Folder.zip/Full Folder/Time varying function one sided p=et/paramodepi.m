clear
close all
A =  [ -1, 10, 0, 0, 0; 
      -10, -1, 0, 0, 0; 
       0, 0, -1, 0, 0; 
       0, 0, 0, -2, 0;
       0, 0, 0, 0, -3];
B = [1;1;1;1;1];
C = [1,1,1,1,1];

%Create 102 values of parameter, 1 for every second between 1-100 and need
%1 extra to evenly match the timespan in the ODE
ft = linspace(0,200,201);

%Define parameter function
%f= (1+100*exp(-1*ft));
f = 1 + 10*ft;
figure
plot(f)

%3D Matrix A(p) varying with time 
%% Need to ensure that A is asympt. stable 

options = odeset('RelTol',1e-8,'AbsTol',1e-8);

global A_vary
for idx = 1:length(f)
    A_vary(:,:,idx) = [ -1, f(idx), 0, 0, 0; 
       -f(idx), -1, 0, 0, 0; 
        0, 0, -1, 0, 0; 
        0, 0, 0, -2, 0;
        0, 0, 0, 0, -3];
end    

%Select S, ensuring no shared eigen values with A
global S
S = [0,1,0,0;
     -1,0,0,0;
     0,0,0,20;
     0,0,-20,0];
%Select L, ensuring (S,L) Observable
global L
L = [1,0,1,0];

%Scale L
L = 10*L;

global PI
for idx = 1:length(f)
    PI_vary(:,:,idx) = sylvester(A_vary(:,:,idx),-S,-B*L);
end

PI_Initial = sylvester(A_vary(:,:,1),-S,-B*L);
tspan = [0, 100];
testpi = PI_Initial;
flat_testpi = reshape(testpi,1,[]);
[t_pi,ResultPi] = ode45(@(t,ResultPi) PiODEet(t,ResultPi,ft,f),tspan,flat_testpi, options);
CheckPi = reshape(ResultPi',5,4,[]);
ShortCheckPi = CheckPi(:,:,1:round(end/10));
% PI = sylvester(A,-S,-B*L);
global fort
fort = t_pi;

%Solve ODE, plug in ft and f for parameter
x0 = rand(9,1); 
tspan = t_pi;
[t,x] = ode45(@(t,x) AltParamODE(t,x,ft,f),tspan,x0,options);

%Matlab vectors are 1-indexed, so need to offset by 1,
temp_t = t+1;  

%Interpolate PI along time axis to create instances between each second

xT = transpose(x);
%Calculate transient response
y = C * xT(5:9,:);

%Calculate ss as p varies
for idx = 1:length(t)
    yss(idx) = C * CheckPi(:,:,idx) * xT(1:4,idx);
end


figure;
plot(t,y);


figure;
plot(t,yss);
hold on
plot(t, y);
hold off
legend('yss','y');

%Create eigen values we desire in the reduced model, using eigen values of
%original system A
for idx = 1:length(f)
    eig_F_vary(:,idx) = [ -1+f(idx)*i, -1-f(idx)*i, -2, -3];
end

%Create G for each second
global G_vary;
for idx = 1:length(f)
    temp1 = eig_F_vary(:,idx);
    temp = place(S',L', temp1);
    G_vary(:,idx)=temp';
end

%Create H for each second
global H_vary;
for idx = 1:length(t)
    H_vary(:,idx)= C*CheckPi(:,:,idx);
end


%Create F for each second
global F_vary
for idx = 1:length(f)
    F_vary(:,:,idx) = S - G_vary(:,idx)*L;
end

global alt_eig_f
alt_eig_f = [-1+5i, -1-5i, -2, -3];

global alt_G
alt_G = place(S',L',alt_eig_f);

global alt_F
alt_F = S- alt_G'*L;

%x1 = rand(8,1);
x1 = x0(1:8);
tspan = t_pi;
[t_red,x_red] = ode45(@(t_red,x) ALTReducedAltParamODE(t_red,x,ft,f),tspan,x1,options);
xT_red = transpose(x_red);


%Calculate reduced transient and ss
for idx = 1:length(t_red)
    y_red(idx) = H_vary(:,idx)'*xT_red(5:8,idx);
    yss_red(idx) = H_vary(:,idx)'*xT_red(1:4,idx);
    alt_yss(idx) = C*CheckPi(:,:,idx)* xT_red(1:4,idx);
end

figure;
plot(t_red, y);
hold on
plot(t_red, y);
hold off
title('Comparison of output and steady state of Original model')
legend('y','yss');


figure;
plot(t_red,y_red);
hold on
plot(t,yss_red);
hold off
title('Comparison of output and steady state of Reduced model')
legend('y','yss');

figure;
plot(t_red,y);
hold on
plot(t,y_red);
hold off
title('Comparison of output of Original and Reduced model')
legend('y','y red');

plot(t,H_vary)
% 
% lpvsys_original = lpvss('p',@dataFcnOriginal);
% freq = logspace(-1,1,100);
% frdModel = frd(lpvsys_original,freq);
% bode(frdModel);
