function dtxt = PiODEet(t,x,ft,f)
dtxt = zeros(20, 1); 
f = interp1(ft,f,t);

global S
global L

A =  [ -1, 0, 0, 0, 0, 
      0, -1, 0, 0, 0,
       0, 0, -1, 0, 0, 
       0, 0, 0, -2, 0,
       0, 0, 0, 0, -3];
   
Dummy = [ 0, 1, 0, 0, 0, 
      -1, 0, 0, 0, 0, 
       0, 0, 0, 0, 0, 
       0, 0, 0, 0, 0,
       0, 0, 0, 0, 0];
B = [1;1;1;1;1];
C = [1,1,1,1,1];
ALTL= [1,1,1,1];

COPY_S = S;
temp = reshape(COPY_S,1,[]);
BL = B*L;
Flat_BL = reshape(BL,1,[]);
Matrix_x = reshape(x,[5,4]);
test1 = kron(f,eye(20));
alt_S = S';
flat_S = reshape(alt_S,1,[]);


dtxt = ([(kron(eye(4),(A+Dummy.*f))- kron(S',eye(5)))] *x + Flat_BL');

%dtxt = [ (   kron(eye(1),reshape((A+Dummy.*f),1,[]) ))- kron(S',eye(20) )    ] *x +Flat_BL;
end
