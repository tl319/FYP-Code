ltvsys = ltvss(@Datafcn);
ltvsys2 = ltvss(@AltDatafcn);


figure
[u,t] = gensig("sine",1,50);
plot(t,lsim(ltvsys,u,t));
hold on
plot(t,lsim(ltvsys2,u,t));
title('System response to sine function')
legend('Original System', 'Reduced system')

figure
plot(t,impulse(ltvsys,t))
hold on
plot(t,impulse(ltvsys2,t))
title('System response to impulse function')
legend('Original System', 'Reduced system')

A =  [ -1, 10, 0, 0, 0; 
      -10, -1, 0, 0, 0; 
       0, 0, -1, 0, 0; 
       0, 0, 0, -2, 0;
       0, 0, 0, 0, -3];
B = [1;1;1;1;1];
C = [1,1,1,1,1];
D = 0;

sys = ss(A,B,C,D);

figure
plot(step(sys));