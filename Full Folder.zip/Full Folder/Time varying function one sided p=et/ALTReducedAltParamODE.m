function dtxt = ALTReducedAltParamODE(t,x,ft,f)
dtxt = zeros(8, 1); 
f = interp1(ft,f,t);
global S
global L
global G_vary
global F_vary


global alt_G

global alt_F

dtxt = [S, zeros(4,4); alt_G'*L, alt_F] * x;
end

