function dtxt = AltParamODE(t,x,ft,f)
dtxt = zeros(9, 1); 
f = interp1(ft,f,t);

global S
global L

A =  [ -1, 0, 0, 0, 0; 
      0, -1, 0, 0, 0; 
       0, 0, -1, 0, 0; 
       0, 0, 0, -2, 0;
       0, 0, 0, 0, -3];
   
Dummy = [ 0, 1, 0, 0, 0; 
      -1, 0, 0, 0, 0; 
       0, 0, 0, 0, 0; 
       0, 0, 0, 0, 0;
       0, 0, 0, 0, 0];
B = [1;1;1;1;1];
C = [1,1,1,1,1];


dtxt = [S, zeros(4,5); B*L, A+(Dummy.*f)] * x;

end
