function dtxt = TwoSideVaryOriODE(t,x,ft,f)
dtxt = zeros(46, 1); 
f = interp1(ft,f,t);

global S
global L
global A
global B
   

Dummy = zeros(40,40);
Dummy(3,4) = 1;
Dummy(4,3) = -1;


dtxt = [S, zeros(6,40); B*L, A+(Dummy.*f)] * x;

end