function dtxt = TwoSideVaryRedODE(t,x,ft,f)
dtxt = zeros(12, 1); 
f = interp1(ft,f,t);

global S
global L
global F
global G
global t_pi
   
[~,index] = min(abs(t_pi-t));
dtxt = [S, zeros(6,6); G(:,index)*L, F(:,:,index)] * x;

end