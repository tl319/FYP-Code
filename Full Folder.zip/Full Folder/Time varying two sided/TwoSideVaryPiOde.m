function dtxt = TwoSideVaryPiOde(t,x,ft,f)
% dtxt = zeros(240,1);
f = interp1(ft,f,t);

global A
global B
global S
global L

FlatBL = reshape(B*L,1,[]);

Dummy = zeros(40,40);
Dummy(3,4) = 1;
Dummy(4,3) = -1;

dtxt = ([kron(eye(6),(A+Dummy.*f)) - kron(S',eye(40))] * x + FlatBL');
end
