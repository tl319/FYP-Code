clear
clear global
close all

global A
A = zeros(40,40);
A(1,1) = -1;
A(2,2) = -1;
A(3,3) = -1;
A(4,4) = -1;
A(1,2) = 60;
A(2,1) = -60;
A(3,4) = 90;
A(4,3) = -90;

for idx = 5:40
    A(idx,idx)= -idx+4;
end

ft = linspace(0,5,6);
f = (10+exp(-0.1*ft));

% f = 0*ft;
global B
B = ones(40,1);
B(1)=1;
B(2)=1;
B(3)=1;
B(4)=1;

global C
C = B';

global S
S = zeros(6,6);
S(1,2) = 0.5;
S(2,1) = -0.5;
S(3,4) = 10;
S(4,3) = -10;
S(5,6) = 30;
S(6,5) = -30;

global Q
Q = zeros(6,6);
Q(1,2) = 1;
Q(2,1) = -1;
Q(3,4) = 25;
Q(4,3) = -25;
Q(5,6) = 120;
Q(6,5) = -120;

A_initial = A;
A_initial(3,4) = A(3,4)+10;
A_initial(4,3) = A(4,3)-10;

global L
L = zeros(1,6);
L = [1,0,1,0,1,0];

global R 
R = L';

options = odeset('RelTol',1e-15,'AbsTol',1e-15);


PI_Initial = sylvester(A_initial,-S,-B*L);
tspan = [0,5];
testpi = PI_Initial;
flat_testpi = reshape(testpi,1,[]);
global t_pi
[t_pi,ResultPi] = ode45(@(t,ResultPi) TwoSideVaryPiOde(t,ResultPi,ft,f),tspan,flat_testpi,options);
CheckPi = reshape(ResultPi',40,6,[]);

Y_Initial = sylvester(Q,-A_initial,L'*C);
testy = Y_Initial;
flat_testy = reshape(testy,1,[]);
tspan = t_pi;
[t_y,ResultY] = ode45(@(t,ResultY) TwoSideVaryYOde(t,ResultY,ft,f),tspan,flat_testy,options);
CheckY = reshape(ResultY',40,6,[]);

x0 = rand(46,1);
tspan = t_pi;
[t,x] = ode45(@(t,x) TwoSideVaryOriODE(t,x,ft,f),tspan,x0,options);
xT = transpose(x);
y = C * xT(7:46,:);
for idx = 1:length(t_pi)
    yss(idx) = C * CheckPi(:,:,idx) * xT(1:6,idx);
end


global G
global H
global F

for idx = 1:length(t_pi)
    Num(:,:,idx) = CheckY(:,:,idx)' * CheckPi(:,:,idx) ;
    Den(:,idx) = (CheckY(:,:,idx)' * B);
    G(:,idx) = (CheckY(:,:,idx)' * CheckPi(:,:,idx)) \ (CheckY(:,:,idx)' * B);
    H(:,idx) = C * CheckPi(:,:,idx);
    F(:,:,idx) = S - G(:,idx)*L;
end



x1 = x0(1:12); 
tspan = t_pi;
[t_red,x_red] = ode45(@(t_red,x_red) TwoSideVaryRedODE(t_red,x_red,ft,f),tspan,x1,options);
xT_red = transpose(x_red);
for idx = 1:length(t_pi)
    y_red(idx) = H(:,idx)' * xT_red(7:12,idx);
    yss_red(idx) = H(:,idx)' * xT_red(1:6,idx);
end

figure
plot(t_red(1:27391),y(1:27391))
hold on
plot(t_red(1:27391),y_red(1:27391))
title('Comparison of output for Original and Reduced model')
legend('y','y red')
