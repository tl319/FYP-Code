function dtxt = TwoSideVaryYOde(t,x,ft,f)
dtxt = zeros(240,1);
f = interp1(ft,f,t);

global A
global C
global Q
global R

FlatRC = reshape(R*C,1,[]);

Dummy = zeros(40,40);
Dummy(3,4) = 1;
Dummy(4,3) = -1;

dtxt = ( [kron(eye(40),Q)-kron((A+Dummy.*f)',eye(6))] *x - FlatRC');
end
