function dtxt = doubleoDE(t,x)
dtxt = zeros(12, 1); 
global Q
global L
global Upsilon_B
global S

dtxt = [Q,Upsilon_B*L; zeros(6,6), S] * x;
end

