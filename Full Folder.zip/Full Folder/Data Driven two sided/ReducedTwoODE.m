function dtxt = ReducedTwoODE(t,x)
dtxt = zeros(12, 1); 

global A

global S
global L
global Q
global R
global H
global Upsilon_B

F = Q-R*H;
G= Upsilon_B;
dtxt = [S, zeros(6,6); G*L, F] * x;
end

