function dtxt = OriginalTwoODE(t,x)
dtxt = zeros(46, 1); 

global A
global B
global S
global L

dtxt = [S, zeros(6,40); B*L, A] * x;
end

