clear 
clear global
close all
% Given Q, R, S, L, A, B, C ,D
global A
A = zeros(40,40);
A(1,1) = -1;
A(2,2) = -1;
A(3,3) = -1;
A(4,4) = -1;
A(1,2) = 1;
A(2,1) = -1;
A(3,4) = 30;
A(4,3) = -30;

for idx = 5:40
    A(idx,idx)= -idx+4;
end

global B
B = ones(40,1);
B(1)=1;
B(2)=1;
B(3)=1;
B(4)=1;

global C
C = B';

global S
S = zeros(6,6);
S(1,2) = 0.5;
S(2,1) = -0.5;
S(3,4) = 10;
S(4,3) = -10;
S(5,6) = 30;
S(6,5) = -30;

global Q
Q = zeros(6,6);
Q(1,2) = 1;
Q(2,1) = -1;
Q(3,4) = 25;
Q(4,3) = -25;
Q(5,6) = 120;
Q(6,5) = -120;

global L
L = zeros(1,6);
L = [1,0,1,0,1,0];

global R 
R = L';


n = 40;
nu = 6;

% x = [x__real w_bar w]; 
% dxdt = [A zeros(n, 1) BL; RC  Q zeros(nu, nu);zeros(nu, n) zeros(nu, nu) S] * x;
% y = [C zeros(1, nu)] * x; 

L = L * 1; 

A_ = [A zeros(n, nu) B*L; R*C  Q zeros(nu, nu); zeros(nu, n) zeros(nu, nu) S];
B_ = zeros(n + 2*nu, 1); 
C_ = [C zeros(1, 2* nu)]; 
sys_twosided = ss(A_, B_, C_, 0); 

x0 = rand(n + 2*nu, 1); 
x0(1:n) = zeros(1,n);
x0(n+nu+1:end) = zeros(1,nu);
tspan = linspace(0, 100, 10000); 
[y,t,x] = lsim(sys_twosided,zeros(10000, 1),tspan,x0); 

figure;
plot(t, x(:, 1:n));
title('x')

figure;
plot(t, x(:, n+1:n+nu));
title('w_{bar}')

figure;
plot(t, x(:, n+nu+1:end));
title('w')


R = L'; 
% dxdt = [A zeros(n, 1);RC  Q] * x + [B; zeros(nu, 1)] * u;
% y = [C zeros(1, nu)] * x; 
A_ = [A zeros(n, nu); R*C  Q];
B_ = [B; zeros(nu, 1)];
C_ = [C zeros(1, nu)]; 
sys_swapped = ss(A_, B_, C_, 0); 

tspan1 = linspace(0, 100, 10000); 
[y1,t1,x1] = impulse(sys_swapped, tspan1); 

figure;
plot(t1, x1(:, 1:n));
title('x')

figure;
plot(t1, x1(:, n+1:end));
title('w')

t_all = t1;
w_all = x1(:, n+1:end); 
sample_frequency = 10; 

% Subsample data
w_sampled = w_all(1:sample_frequency:end, :);
t_sampled = t_all(1:sample_frequency:end, :);
n_sample = size(t_sampled, 1);
window_len = 10;
impulse_start_time = 0;
t_calibrated = t_sampled - impulse_start_time;  % real time starting from when the impulse comes in

idxs = (n_sample - window_len) : n_sample;
W = zeros(window_len * nu, 1);
EXPST = zeros(window_len * nu, nu);

for i = 1:window_len
   idx = idxs(i);
   t = t_calibrated(idx);
   W((i-1)*nu+1: i*nu,:) = w_sampled(idx, :);
   EXPST((i-1)*nu+1: i*nu,:) = expm(Q * t);
end

% Estimate Upsilon * B
global Upsilon_B;
Upsilon_B = EXPST \ W
TRUE_Y = sylvester(Q, -A, L' * C);
TRUE_Y * B

wfinal = x(:, n+1:n+nu);
wbarfinal = x(:, n+nu+1:end);
temp = wfinal(end,:);
x0_D = zeros(12,1);
x0_D(7:12)=rand(1,6);

% x0_D(5:8)=x(end, n+nu+1:end);
% tspan_D = [0, 100];
tspan_D = t_all;
[t_D,x_D] = ode45(@doubleODE,tspan_D,x0_D);
xT_D = x_D;
%xT_D = transpose(x_D);
dfinal = xT_D(:,1:6);
pfinal = dfinal - wbarfinal;
ofinal = zeros(6,36,10000);
for idx = 1:10000
    ofinal(:,:,idx) = kron(wfinal(idx,:),eye(6));
end
size([ofinal(:,:,end-3); ofinal(:,:,end-2); ofinal(:,:,end-1);ofinal(:,:,end-0)]);
TrueOfinal(1:36,1:36) = [ofinal(:,:,end-5); ofinal(:,:,end-4); ofinal(:,:,end-3); ofinal(:,:,end-2); ofinal(:,:,end-1);ofinal(:,:,end-0)];

TruePfinal(1:36,1)= [pfinal(end-5,:)';
    pfinal(end-4,:)';
    pfinal(end-3,:)';
pfinal(end-2,:)';
pfinal(end-1,:)';
pfinal(end-0,:)';
];
YPI = TrueOfinal \ TruePfinal;

% for idx = 1:10000
%     YPI(:,idx) = ofinal(:,:,idx) \ pfinal(:,idx);
% end
%YPI = (wfinal' * wfinal) \ (wfinal' * pfinal);

% YPI = (ofinal' * ofinal) \ (ofinal' * pfinal);

TRUE_PI = sylvester(A,-S,-B*L);
TRUE_YPI = TRUE_Y * TRUE_PI;
flatYPI = reshape(TRUE_YPI,1,[]);
Square_YPi = reshape(YPI,6,6);


x0_Actual = rand(46,1); 
tspan = [0, 100];
[t,x_Actual] = ode45(@OriginalTwoODE,tspan,x0_Actual);
xT_Actual = transpose(x_Actual);
y_Actual = C * xT_Actual(7:46,:);
yss_Actual  = C * TRUE_PI * xT_Actual(1:6,:);

dataw = xT_Actual(1:6, end-20:end)';
datay = y_Actual (:, end-20:end)';
CPI = dataw \ datay;

global H
H = CPI \ Square_YPi;
Precise_H = (C*TRUE_PI)' \ TRUE_YPI;
% errorH = H - Precise_H
errorYB = Upsilon_B - TRUE_Y * B

x1_Actual = x0_Actual(1:12);
tspan = t;
[t,x_red_Actual] = ode45(@ReducedTwoODE,tspan,x1_Actual);
xT_Red_Actual = x_red_Actual';
y_Red_Actual = Precise_H * xT_Red_Actual(7:12,:);
yss_Red_Actual = H  * xT_Red_Actual(1:6,:);

figure
plot(t,y_Actual);
hold on
plot(t,yss_Actual);
title('Comparison of original and reduced model output')
legend('y','y red')