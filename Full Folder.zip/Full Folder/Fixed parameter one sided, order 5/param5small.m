clear 
close all

ft = linspace(0,11,12);
f= (15+(ft));

global A
A = [-1,0,0,0,0;
     0,-1,0,0,0;
     0,0,-1,0,0;
     0,0,0,-2,0;
     0,0,0,0,-3];
global B
B = [1;1;1;1;1];
global C
C = [1,1,1,1,1];

bode(A,B,C,0)

global A_vary
for idx = 1:length(f)
    A_vary(:,:,idx) = A;
    A_vary(1,2,idx) = f(idx);
    A_vary(2,1,idx) = -f(idx);
end    

global S
S = [0 0, 0;
    0 0,21.5;
    0,-21.5,0];

global L
L = [1,1,0];

global Pi_vary
for idx = 1:length(f)
    Pi_vary(:,:,idx) = sylvester(A_vary(:,:,idx),-S,-B*L);
end   

global Pi_Midpoint
Pi_Midpoint = sylvester(A_vary(:,:,6),-S,-B*L);

global Pi_Average
Pi_Average = zeros(5,3);
for idx = 1:length(f)
    Pi_Average(:,:) = Pi_Average(:,:) + Pi_vary(:,:,idx);
end
Pi_Average = Pi_Average / length(f);

x0 = rand(8,1);
x0 = [x0,x0,x0,x0,x0,x0,x0,x0,x0,x0,x0,x0];
tspan = [0, 100];
[t,x] = ode45(@OriginalSystemODEsmall,tspan,x0);
xT= x';
for idx = 1:length(f)
    Cnt = idx*8;
    y(:,idx)= C * xT((Cnt-4:Cnt),:);
    yss_midpoint(:,idx) = C * Pi_Midpoint * xT((Cnt-7:Cnt-5),:);
    yss_average(:,idx) = C * Pi_Average * xT((Cnt-7:Cnt-5),:);
    yss_correct(:,idx) = C * Pi_vary(:,:,idx) * xT((Cnt-7:Cnt-5),:);
end
% 
% for idx = 1:length(f)
%     figure
%     plot(t,y(:,idx));
%     hold on
%     plot(t,yss_midpoint(:,idx));
%     hold on
%     plot(t,yss_average(:,idx));
%     hold on
%     plot(t,yss_correct(:,idx));
%     hold on
%     title('Original model for p= ', idx);
%     legend('y','yss mid','yss avg','yss correct')
%     hold off
% end

global eig_F_vary
eig_F_vary = zeros(3,12);
for idx = 1:length(f);
    eig_F_vary(:,idx) = [ -1 + f(idx)*i, -1 - f(idx)*i, -2];
end

global eig_F_Average
eig_F_Average = zeros(1,3);
for idx = 1:length(f)
    eig_F_Average = eig_F_Average + eig_F_vary(:,idx);
end
eig_F_Average = eig_F_Average / length(f);

global eig_F_Midpoint
eig_F_Midpoint = [ -1 + f(6)*i, -1 - f(6)*i, -2];

global G_vary
for idx = 1:length(f)
    G_vary(:,idx) = place(S',L',eig_F_vary(:,idx));
end

global G_Midpoint 
G_Midpoint = place(S',L',eig_F_Midpoint);

global G_Average 
G_Average = place(S',L',eig_F_Midpoint);

global H_vary
for idx = 1:length(f);
    H_vary(:,idx) = C * Pi_vary(:,:,idx);
end
global H_midpoint
H_midpoint = C * Pi_Midpoint;

global H_average
H_average = C * Pi_Average;

global F_vary
for idx = 1:length(f);
    F_vary(:,:,idx) = S - G_vary(:,idx)*L;
end

global F_midpoint
F_midpoint = S - G_Midpoint' * L;

global F_average
F_average = S - G_Average' * L;

x1 = x0(1:6);
x1 = [x1,x1,x1,x1,x1,x1,x1,x1,x1,x1,x1,x1];
tspan = t;
[t_red_g_vary,x_red_g_vary] = ode45(@ReducedSystemODE_varysmall,tspan,x1);
xT_red_g_vary= x_red_g_vary';
for idx = 1:length(f)
    Cnt = idx*6;
    y_red_midpoint_g_vary(:,idx)=  H_midpoint * xT_red_g_vary((Cnt-2:Cnt),:);
    y_red_average_g_vary(:,idx)=  H_average * xT_red_g_vary((Cnt-2:Cnt),:);
    y_red_vary_g_vary(:,idx)=  H_vary(:,idx)' * xT_red_g_vary((Cnt-2:Cnt),:);
    yss_red_midpoint_g_vary(:,idx) = H_midpoint * xT_red_g_vary((Cnt-5:Cnt-3),:);
    yss_red_average_g_vary(:,idx) = H_average * xT_red_g_vary((Cnt-5:Cnt-3),:);
    yss_red_correct_g_vary(:,idx) = H_vary(:,idx)' * xT_red_g_vary((Cnt-5:Cnt-3),:);
end

% for idx = 1:length(f)
%     figure
%     plot(t,y_red_midpoint_g_vary(:,idx));
%     hold on
%     plot(t,y_red_average_g_vary(:,idx));
%     hold on
%     plot(t,y_red_vary_g_vary(:,idx));
%     hold on
%     plot(t,yss_red_midpoint_g_vary(:,idx));
%     hold on
%     plot(t,yss_red_average_g_vary(:,idx));
%     hold on
%     plot(t,yss_red_correct_g_vary(:,idx));
%     hold on
%     title('Reduce model with varying G for p= ', idx);
%     legend('y red mid','y red avg','y red vary','yss red mid','yss red avg','yss red correct')
%     hold off
% end
% 
% for idx = 1:length(f)
%     figure
%     plot(t,y(:,idx));
%     hold on
%     plot(t,y_red_midpoint_g_vary(:,idx));
%     hold on
%     plot(t,y_red_average_g_vary(:,idx));
%     hold on
%     plot(t,y_red_vary_g_vary(:,idx));
%     hold on
%     title('Comparing outputs of models with varying G for p= ', idx);
%     legend('y', 'y red mid','y red avg','y red vary')
%     hold off
% end

[t_red_g_average,x_red_g_average] = ode45(@ReducedSystemODE_Averagesmall,tspan,x1);
xT_red_g_average= x_red_g_average';
for idx = 1:length(f)
    Cnt = idx*6;
    y_red_midpoint_g_average(:,idx)=  H_midpoint * xT_red_g_average((Cnt-2:Cnt),:);
    y_red_average_g_average(:,idx)=  H_average * xT_red_g_average((Cnt-2:Cnt),:);
    y_red_vary_g_average(:,idx)=  H_vary(:,idx)' * xT_red_g_average((Cnt-2:Cnt),:);
    yss_red_midpoint_g_average(:,idx) = H_midpoint * xT_red_g_average((Cnt-5:Cnt-3),:);
    yss_red_average_g_average(:,idx) = H_average * xT_red_g_average((Cnt-5:Cnt-3),:);
    yss_red_correct_g_average(:,idx) = H_vary(:,idx)' * xT_red_g_average((Cnt-5:Cnt-3),:);
end

error1 = sum(norm(y(:,1) - y_red_vary_g_average(:,1)));
error2 = sum(norm(y(:,1) - y_red_average_g_average(:,1)));

error3 = sum(norm(y(:,6) - y_red_vary_g_average(:,6)));
error4 = sum(norm(y(:,6) - y_red_average_g_average(:,6)));

error5 = sum(norm(y(:,11) - y_red_vary_g_average(:,11)));
error6 = sum(norm(y(:,11) - y_red_average_g_average(:,11)));

error1yss = sum(norm(yss_correct(:,1) - yss_red_correct_g_average(:,1)));
error2yss = sum(norm(yss_correct(:,1) -yss_red_average_g_average(:,1)));

error3yss = sum(norm(yss_correct(:,6) - yss_red_correct_g_average(:,6)));
error4yss = sum(norm(yss_correct(:,6) -yss_red_average_g_average(:,6)));

error5yss = sum(norm(yss_correct(:,11) - yss_red_correct_g_average(:,11)));
error6yss = sum(norm(yss_correct(:,11) -yss_red_average_g_average(:,11)));


% figure
% plot(t,y(:,1))
% hold on
% plot(t,y_red_vary_g_average(:,1))
% hold on
% plot(t,y_red_average_g_average(:,1))
% hold on
% title('Comparing outputs of models for p= 15');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% figure
% plot(t,y(:,6))
% hold on
% plot(t,y_red_vary_g_average(:,6))
% hold on
% plot(t,y_red_average_g_average(:,6))
% hold on
% title('Comparing outputs of models for p= 21');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% figure
% plot(t,y(:,11))
% hold on
% plot(t,y_red_vary_g_average(:,11))
% hold on
% plot(t,y_red_average_g_average(:,11))
% hold on
% title('Comparing outputs of models for p= 26');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% 
% figure
% plot(t,yss_correct(:,1))
% hold on
% plot(t,yss_red_correct_g_average(:,1))
% hold on
% plot(t,yss_red_average_g_average(:,1))
% hold on
% title('Comparing outputs of models for p= 1');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% figure
% plot(t,yss_correct(:,6))
% hold on
% plot(t,yss_red_correct_g_average(:,6))
% hold on
% plot(t,yss_red_average_g_average(:,6))
% hold on
% title('Comparing outputs of models for p= 6');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% figure
% plot(t,yss_correct(:,11))
% hold on
% plot(t,yss_red_correct_g_average(:,11))
% hold on
% plot(t,yss_red_average_g_average(:,11))
% hold on
% title('Comparing outputs of models for p= 11');
% legend('y', 'y red with correct PI','y red with averaged PI')
% 
% figure
% plot(t,y(:,1))
% hold on
% plot(t,y_red_vary_g_vary(:,1))
% hold on
% plot(t,y_red_vary_g_average(:,1))
% title('Comparing outputs of models for p= 15');
% legend('y', 'y red with correct G','y red with averaged G')
% errorG1 = sum(norm(y(:,1) - y_red_vary_g_vary(:,1)));
% errorG2 = sum(norm(y(:,1) - y_red_vary_g_average(:,1)));
% 
% sys1 = ss(A_vary(:,:,1),B,C,0);
% sys1G = ss(F_vary(:,:,1),G_vary(:,1),H_vary(:,1)',0);
% sys1Gavg = ss(F_average,G_Average',H_vary(:,1)',0);
% 
% figure
% bode(sys1,sys1G,sys1Gavg)
% title('Comparing bode plots of models with p = 15');
% legend('Original model', 'Reduced model with parameterised G','Reduced model with averaged G')
% 
% figure
% plot(t,y(:,6))
% hold on
% plot(t,y_red_vary_g_vary(:,6))
% hold on
% plot(t,y_red_vary_g_average(:,6))
% title('Comparing outputs of models for p= 21');
% legend('y', 'y red with correct G','y red with averaged G')
% errorG3 = sum(norm(y(:,1) - y_red_vary_g_vary(:,6)));
% errorG4 = sum(norm(y(:,1) - y_red_vary_g_average(:,6)));
% 
% sys2 = ss(A_vary(:,:,6),B,C,0);
% sys2G = ss(F_vary(:,:,6),G_vary(:,6),H_vary(:,6)',0);
% sys2Gavg = ss(F_average,G_Average',H_vary(:,6)',0);
% 
% figure
% bode(sys2,sys2G,sys2Gavg)
% title('Comparing bode plots of models with p = 21');
% legend('Original model', 'Reduced model with parameterised G','Reduced model with averaged G')
% 
% figure
% plot(t,y(:,11))
% hold on
% plot(t,y_red_vary_g_vary(:,11))
% hold on
% plot(t,y_red_vary_g_average(:,11))
% title('Comparing outputs of models for p= 26');
% legend('y', 'y red with correct G','y red with averaged G')
% errorG5 = sum(norm(y(:,1) - y_red_vary_g_vary(:,11)));
% errorG6 = sum(norm(y(:,1) - y_red_vary_g_average(:,11)));
% 
% sys3 = ss(A_vary(:,:,11),B,C,0);
% sys3G = ss(F_vary(:,:,11),G_vary(:,11),H_vary(:,11)',0);
% sys3Gavg = ss(F_average,G_Average',H_vary(:,11)',0);
% 
% figure
% bode(sys3,sys3G,sys3Gavg)
% title('Comparing bode plots of models with p = 26');
% legend('Original model', 'Reduced model with parameterised G','Reduced model with averaged G')
% 

% for idx = 1:length(f)
%     figure
%     plot(t,y(:,idx));
%     hold on
%     plot(t,y_red_midpoint_g_vary(:,idx));
%     hold on
%     plot(t,y_red_average_g_vary(:,idx));
%     hold on
%     plot(t,y_red_vary_g_vary(:,idx));
%     hold on
%     plot(t,y_red_midpoint_g_average(:,idx));
%     hold on
%     plot(t,y_red_average_g_average(:,idx));
%     hold on
%     plot(t,y_red_vary_g_average(:,idx));
%     hold on
%     title('Comparing outputs of models with varying G for p= ', idx);
%     legend('y', 'y red mid','y red avg','y red vary', 'y red mid gavg','y red avg gavg','y red vary gavg')
%     hold off
% end


% 
% sys_original = ss(A_vary(:,:,1),B,C,0);
% sys_reduced_vary  = ss(F_vary(:,:,1),G_vary(:,1),H_vary(:,1)',0);
% sys_reduced_avg  = ss(F_average,G_Average',H_vary(:,1)',0);
% sys_reduced_mid  = ss(F_midpoint,G_Midpoint',H_vary(:,1)',0);
% 
% figure
% bode(sys_original,sys_reduced_mid,sys_reduced_vary,sys_reduced_avg)
% legend('orig','vary','avg','mid');
% 
% sys1 = ss(A_vary(:,:,1),B,C,0);
% sys1mid = ss(F_midpoint,G_Midpoint',H_midpoint,0);
% sys2 = ss(A_vary(:,:,2),B,C,0);
% sys3 = ss(A_vary(:,:,3),B,C,0);
% sys4 = ss(A_vary(:,:,4),B,C,0);
% sys5 = ss(A_vary(:,:,5),B,C,0);
% sys6 = ss(A_vary(:,:,6),B,C,0);
% sys7 = ss(A_vary(:,:,7),B,C,0);
% sys8 = ss(A_vary(:,:,8),B,C,0);
% sys9 = ss(A_vary(:,:,9),B,C,0);
% sys10 = ss(A_vary(:,:,10),B,C,0);
% sys11 = ss(A_vary(:,:,11),B,C,0);
% 
% sys1changeg  = ss(F_vary(:,:,1),G_vary(:,1),H_average,0);
% sys1changeCP  = ss(F_vary(:,:,1),G_Average',H_vary(:,1)',0);
% 
% figure
% bode(sys1,sys1changeg,sys1changeCP);
% legend('original','change CPI', 'change G')
% 
% [mag1,phase1,wout1] = bode(sys1);
% [mag2,phase2,wout2] = bode(sys1changeg);
% [mag3,phase3,wout3] = bode(sys1changeCP);

alty1 = y(:,1)';
alty2 = y(:,12)';
datay1 = alty1(:,end-20:end)';
datay2 = alty2(:,end-20:end)';
moments1 = xT(1:3,:);
moments2 = xT(89:91,:);
dataw1 = moments1(:,end-20:end)';
dataw2 = moments2(:,end-20:end)';

CPI1 = dataw1 \ datay1;
CPI2 = dataw2 \ datay2;

errorpi1 = CPI1 - C*Pi_vary(:,1);
errorpi2 = CPI2 - C*Pi_vary(:,12);


