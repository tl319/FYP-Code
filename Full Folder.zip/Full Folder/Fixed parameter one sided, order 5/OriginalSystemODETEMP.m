function dtxt = OriginalSystemODETEMP(t,x)
dtxt = zeros(9, 1); 

global S
global L
global A_vary

   

global B
global C


dtxt = [S, zeros(4,5), ; B*L, A_vary(:,:,1)] *x;

end
