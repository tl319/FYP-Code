function dtxt = ReducedSystemODE_Averagesmall(t,x)
dtxt = zeros(72, 1); 

global S
global L
global G_Average
global F_average

dtxt = [            S, zeros(3,3), zeros(3,66);              G_Average'*L, F_average, zeros(3,66);
        zeros(3,6), S, zeros(3,3), zeros(3,60); zeros(3,6),  G_Average'*L, F_average, zeros(3,60);
        zeros(3,12),S, zeros(3,3), zeros(3,54); zeros(3,12), G_Average'*L, F_average, zeros(3,54);
        zeros(3,18),S, zeros(3,3), zeros(3,48); zeros(3,18), G_Average'*L, F_average, zeros(3,48);
        zeros(3,24),S, zeros(3,3), zeros(3,42); zeros(3,24), G_Average'*L, F_average, zeros(3,42);
        zeros(3,30),S, zeros(3,3), zeros(3,36); zeros(3,30), G_Average'*L, F_average, zeros(3,36);
        zeros(3,36),S, zeros(3,3), zeros(3,30); zeros(3,36), G_Average'*L, F_average, zeros(3,30);
        zeros(3,42),S, zeros(3,3), zeros(3,24); zeros(3,42), G_Average'*L, F_average, zeros(3,24);
        zeros(3,48),S, zeros(3,3), zeros(3,18); zeros(3,48), G_Average'*L, F_average, zeros(3,18);
        zeros(3,54),S, zeros(3,3), zeros(3,12); zeros(3,54), G_Average'*L, F_average, zeros(3,12);
        zeros(3,60),S, zeros(3,3), zeros(3,6);  zeros(3,60), G_Average'*L, F_average, zeros(3,6);
        zeros(3,66),S, zeros(3,3), zeros(3,0);  zeros(3,66), G_Average'*L, F_average, zeros(3,0);

] * x;

end
