function dtxt = ReducedSystemODE_Varysmall(t,x)
dtxt = zeros(72, 1); 

global S
global L
global G_vary
global F_vary


dtxt = [S, zeros(3,3), zeros(3,66); G_vary(:,1)*L, F_vary(:,:,1), zeros(3,66);
        zeros(3,6),S, zeros(3,3), zeros(3,60); zeros(3,6), G_vary(:,2)*L, F_vary(:,:,2), zeros(3,60);
        zeros(3,12),S, zeros(3,3), zeros(3,54); zeros(3,12), G_vary(:,3)*L, F_vary(:,:,3), zeros(3,54);
        zeros(3,18),S, zeros(3,3), zeros(3,48); zeros(3,18), G_vary(:,3)*L, F_vary(:,:,3), zeros(3,48);
        zeros(3,24),S, zeros(3,3), zeros(3,42); zeros(3,24), G_vary(:,5)*L, F_vary(:,:,5), zeros(3,42);
        zeros(3,30),S, zeros(3,3), zeros(3,36); zeros(3,30), G_vary(:,6)*L, F_vary(:,:,6), zeros(3,36);
        zeros(3,36),S, zeros(3,3), zeros(3,30); zeros(3,36), G_vary(:,7)*L, F_vary(:,:,7), zeros(3,30);
        zeros(3,42),S, zeros(3,3), zeros(3,24); zeros(3,42), G_vary(:,8)*L, F_vary(:,:,8), zeros(3,24);
        zeros(3,48),S, zeros(3,3), zeros(3,18); zeros(3,48), G_vary(:,9)*L, F_vary(:,:,9), zeros(3,18);
        zeros(3,54),S, zeros(3,3), zeros(3,12); zeros(3,54), G_vary(:,10)*L, F_vary(:,:,10), zeros(3,12);
        zeros(3,60),S, zeros(3,3), zeros(3,6); zeros(3,60), G_vary(:,11)*L, F_vary(:,:,11), zeros(3,6);
        zeros(3,66),S, zeros(3,3), zeros(3,0); zeros(3,66), G_vary(:,12)*L, F_vary(:,:,12), zeros(3,0);

] * x;

end
