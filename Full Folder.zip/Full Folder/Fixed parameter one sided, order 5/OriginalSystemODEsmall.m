function dtxt = OriginalSystemODEsmall(t,x)
dtxt = zeros(96, 1); 

global S
global L
global A_vary

   

global B
global C


dtxt = [S, zeros(3,5), zeros(3,88); B*L, A_vary(:,:,1), zeros(5,88);
        zeros(3,8),S, zeros(3,5), zeros(3,80); zeros(5,8), B*L, A_vary(:,:,2), zeros(5,80);
        zeros(3,16),S, zeros(3,5), zeros(3,72); zeros(5,16), B*L, A_vary(:,:,3), zeros(5,72);
        zeros(3,24),S, zeros(3,5), zeros(3,64); zeros(5,24), B*L, A_vary(:,:,3), zeros(5,64);
        zeros(3,32),S, zeros(3,5), zeros(3,56); zeros(5,32), B*L, A_vary(:,:,5), zeros(5,56);
        zeros(3,40),S, zeros(3,5), zeros(3,48); zeros(5,40), B*L, A_vary(:,:,6), zeros(5,48);
        zeros(3,48),S, zeros(3,5), zeros(3,40); zeros(5,48), B*L, A_vary(:,:,7), zeros(5,40);
        zeros(3,56),S, zeros(3,5), zeros(3,32); zeros(5,56), B*L, A_vary(:,:,8), zeros(5,32);
        zeros(3,64),S, zeros(3,5), zeros(3,24); zeros(5,64), B*L, A_vary(:,:,9), zeros(5,24);
        zeros(3,72),S, zeros(3,5), zeros(3,16); zeros(5,72), B*L, A_vary(:,:,10), zeros(5,16);
        zeros(3,80),S, zeros(3,5), zeros(3,8); zeros(5,80), B*L, A_vary(:,:,11), zeros(5,8);
        zeros(3,88),S, zeros(3,5), zeros(3,0); zeros(5,88), B*L, A_vary(:,:,12), zeros(5,0);
] * x;

end
