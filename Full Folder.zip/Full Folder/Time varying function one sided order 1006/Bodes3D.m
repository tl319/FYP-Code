%clear 
close all

global A_fom
A_fom = full(A);

S = full(S);
global B_fom
%B_fom = ones(1006,1);
B_fom=B;
global C_fom;
%C_fom = ones(1,1006);
C_fom=C;

ft = linspace(0,10,11);


f= (1+10*(ft));

global A_vary_real
for idx = 1:30:length(t)
    A_vary_real(:,:,idx) = A_fom;
    A_vary_real(5,6) = 400-(1+10*(t(idx)));
    A_vary_real(6,5) = -400+(1+10*(t(idx)));
end    

check = 1
for idx = 1:30:length(t)
    Pi_Bode(:,:,idx) = sylvester(A_vary_real(:,:,idx),-S,-B_fom*L);
end

check =2
for idx = 1:30:length(t)
    sys = ss(A_vary_real(:,:,idx),B_fom,C_fom,0);
    [mag,phase,wout] = bode(sys);
    Resmag(:,idx) = mag;
    Resphase(:,idx) = phase;
end
check = 3

for idx = 1:30:length(t)
    sys = ss(alt_F_real,alt_G_real',H_vary_real(:,idx)',0)
    [mag,phase,wout] = bode(sys);
    Redmag(:,idx) = mag;
    Redphase(:,idx) = phase;
end