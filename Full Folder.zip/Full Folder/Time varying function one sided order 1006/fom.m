%clear 
close all

global A_fom
A_fom = full(A);


global B_fom
%B_fom = ones(1006,1);
B_fom=B;
global C_fom;
%C_fom = ones(1,1006);
C_fom=C;

ft = linspace(0,3,4);


f= (10+50*exp(-0.1*ft));

sys = ss(A_fom,B_fom,C_fom,0);
bode(sys);

figure
plot(f)

%3D Matrix A(p) varying with time 
%% Need to ensure that A is asympt. stable 

global A_vary_real
for idx = 1:length(f)
    A_vary_real(:,:,idx) = A_fom;
    A_vary_real(5,6) = 400-f(idx);
    A_vary_real(6,5) = -400+f(idx);
end    

%Select S, ensuring no shared eigen values with A
global S

S = zeros(16,16);
S(1,1) = 0; S(1,2) = 1; S(2,1) = -1; S(2,2) = 0;
S(3,3) = 0; S(3,4) = 50; S(4,3) = -50; S(4,4) = 0;
S(5,5) = 0; S(5,6) = 100; S(6,5) = -100; S(6,6) = 0;
S(7,7) = 0; S(7,8) = 200; S(8,7) = -200; S(8,8) = 0;
S(9,9) = 0; S(9,10) = 400; S(10,9) = -400; S(10,10) = 0;
S(11,11) = 0; S(11,12) = 75; S(12,11) = -75; S(12,12) = 0;
S(13,13) = 0; S(13,14) = 500; S(14,13) = -500; S(14,12) = 0;
S(15,15) = 0; S(15,16) = 700; S(16,15) = -700; S(16,12) = 0;

%Select L, ensuring (S,L) Observable
global L
L = zeros(1,16);
L(1,1) = 1; L(1,2) = 0; L(1,3) = 1; L(1,4) = 0;
L(1,5) = 1; L(1,6) = 0; L(1,7) = 1; L(1,8) = 0;
L(1,9) = 1; L(1,10) = 0; L(1,11) = 1; L(1,12) = 0;
L(1,13) = 1; L(1,14) = 0; L(1,15) = 1; L(1,16) = 0;

%Scale L
L = L;

global PI

% PI_Initial = sylvester(A_vary_real(:,:,1),-S,-B_fom*L);
% tspan = [0, 3];
% testpi = PI_Initial;
% flat_testpi = reshape(testpi,1,[]);
% [t_pi,ResultPi] = ode113(@(t,ResultPi) PiODE1006(t,ResultPi,ft,f),tspan,flat_testpi);
% CheckPi = reshape(ResultPi',1006,16,[]);


%Solve ODE, plug in ft and f for parameter
% x0 = rand(1022,1); 
% tspan = t_pi;
% [t,x] = ode45(@(t,x) AltParamODE1006(t,x,ft,f),tspan,x0);

%Matlab vectors are 1-indexed, so need to offset by 1,
temp_t = t+1;  

%Interpolate PI along time axis to create instances between each second

xT = transpose(x);
%Calculate transient response
y = C_fom * xT(17:1022,:);

%Calculate ss as p varies
for idx = 1:length(t)
    yss(idx) = C_fom * CheckPi(:,:,idx) * xT(1:16,idx);
end


figure;
plot(t,y);


figure;
plot(t, yss);
hold on
plot(t, y);
hold off
legend('yss','y');


%Create H for each second
global H_vary_real;
for idx = 1:length(t)
    H_vary_real(:,idx)= C_fom*CheckPi(:,:,idx);
end

ob=ctrb(S',L');
unob = length(S')-rank(ob);
global alt_eig_f_real
%alt_eig_f_real = [ -1+100*i, -1-100*i, -1+200*i, -1-200*i, -1+400*i, -1-400*i, -33, -150, -250, -350, -450, -550, -650, -750, -910, -1000,];
alt_eig_f_real = [ -1+100*i, -1-100*i, -20+200*i, -20-200*i, -40+400*i, -40-400*i, 0, -100, -250, -350, -450, -550, -650, -750, -910, -1000,];
%alt_eig_f_real = [ -1+100*i, -1-100*i, -1+200*i, -1-200*i, -1+400*i, -1-400*i, -33, -150, -250, -350, -450, -550, -650, -750, -999, -1000,];
%alt_eig_f_real = [ 0, -40, -80, -150, -200, -230, -300, -340, -410, -480, -520, -590, -650, -750, -999, -1000,];

global alt_G_real
alt_G_real = place(S',L',alt_eig_f_real);

global alt_F_real
alt_F_real = S- alt_G_real'*L;

%x1 = rand(8,1);
x1 = x0(1:32);
tspan = t;
[t_red,x_red] = ode45(@(t,x) ALTReducedAltParamODE1006(t,x,ft,f),tspan,x1);
xT_red = transpose(x_red);


%Calculate reduced transient and ss
for idx = 1:length(t_red)
    y_red(idx) = H_vary_real(:,idx)'*xT_red(17:32,idx);
    yss_red(idx) = H_vary_real(:,idx)'*xT_red(1:16,idx);
end

figure;
plot(t_red, y_red);
hold on
plot(t_red, yss_red);
hold off
title('Comparison of output and steady state of Reduced model')
legend('y red','yss red');


figure;
plot(t_red,y);
hold on
plot(t,y_red);
hold off
title('Comparison of output of Original and Reduced model')
legend('y ','y red');

figure;
plot(t_red,y);
hold on
plot(t,yss);
hold off
title('Comparison of output and steady state of Original model')
legend('y','yss');
% 
% lpvsys_original = lpvss('p',@dataFcnOriginal);
% freq = logspace(-1,1,100);
% frdModel = frd(lpvsys_original,freq);
% bode(frdModel);
