function dtxt = ALTReducedAltParamODE1006(t,x,ft,f)
dtxt = zeros(32, 1); 
f = interp1(ft,f,t);
global S
global L
global G_vary
global F_vary


global alt_G_real
global alt_F_real

t
dtxt = [S, zeros(16,16); alt_G_real'*L, alt_F_real] * x;
end

